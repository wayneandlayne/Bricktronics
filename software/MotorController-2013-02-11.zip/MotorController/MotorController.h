/* Bricktronics MotorController Library
Copyright (C) 2013 Adam Wolf, Matthew Beckler, John Baichtal

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#ifndef MOTOR_CONTROLLER_H
#define MOTOR_CONTROLLER_H

#include <inttypes.h>
#include "utility/Encoder.h"
#include "utility/Adafruit_MCP23017.h"
#include "utility/SoftI2cMaster.h"
#include "utility/digitalWriteFast.h"

#include "Motor.h"

#if ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

// This is the amount of time to delay for when using PIDMotor
#define DELAY_UPDATE_MS 50

#define MOTOR_1_EN 64
#define MOTOR_1_PWM 3
#define MOTOR_1_DIR 65
#define MOTOR_1_TACH_0 A0
#define MOTOR_1_TACH_1 A1

#define MOTOR_2_EN 66
#define MOTOR_2_PWM 5
#define MOTOR_2_DIR 67
#define MOTOR_2_TACH_0 A2
#define MOTOR_2_TACH_1 A3

#define MOTOR_3_EN 68
#define MOTOR_3_PWM 6
#define MOTOR_3_DIR 69
#define MOTOR_3_TACH_0 2
#define MOTOR_3_TACH_1 4

#define MOTOR_4_EN 70
#define MOTOR_4_PWM 9
#define MOTOR_4_DIR 71
#define MOTOR_4_TACH_0 13
#define MOTOR_4_TACH_1 12

#define MOTOR_5_EN 72
#define MOTOR_5_PWM 10
#define MOTOR_5_DIR 73
#define MOTOR_5_TACH_0 7
#define MOTOR_5_TACH_1 8

// TODO defines for the XBEE hardware?

class Motor;
class PIDMotor;

class MotorController
{
    public:
        MotorController();
        void begin();
        Adafruit_MCP23017 mcp;
        void digitalWrite(uint8_t pin, uint8_t level);
        uint8_t digitalRead(uint8_t pin);
        void pinMode(uint8_t pin, uint8_t mode);
        void pullUp(uint8_t pin, uint8_t level);
        static void delay_update(uint16_t ms, PIDMotor* m1, PIDMotor* m2, PIDMotor* m3, PIDMotor* m4, PIDMotor* m5);
    private:
};

#endif
