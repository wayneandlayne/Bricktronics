#include "MotorController.h"

// TODO are these needed?
#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include <Wire.h>

MotorController::MotorController() 
{
}

void MotorController::delay_update(uint16_t delay_ms, PIDMotor* m1, PIDMotor* m2, PIDMotor* m3, PIDMotor* m4, PIDMotor* m5)
{
    unsigned long end_time = millis() + delay_ms;
    while (millis() < end_time)
    {
        if (m1) m1->update();
        if (m2) m2->update();
        if (m3) m3->update();
        if (m4) m4->update();
        if (m5) m5->update();
        delay(DELAY_UPDATE_MS);
    }
}

void MotorController::pinMode(uint8_t pin, uint8_t mode)
{
    if (pin < 64)
    {
        ::pinMode(pin, mode);
    }
    else
    {
        mcp.pinMode(pin-64, mode);
    }
}

void MotorController::digitalWrite(uint8_t pin, uint8_t level)
{
    if (pin < 64)
    {
        ::digitalWrite(pin, level);
    }
    else
    {
        mcp.digitalWrite(pin-64, level);
    }
}

uint8_t MotorController::digitalRead(uint8_t pin)
{
    if (pin < 64)
    {
        return ::digitalRead(pin);
    }
    else
    {
        return mcp.digitalRead(pin-64);
    }
}

void MotorController::pullUp(uint8_t pin, uint8_t level)
{
    if (pin < 64)
    {
        digitalWrite(pin, level);
    }
    else
    {
        mcp.pullUp(pin-64, level);
    }
}

void MotorController::begin()
{
    Wire.begin();
    mcp.begin();
}
