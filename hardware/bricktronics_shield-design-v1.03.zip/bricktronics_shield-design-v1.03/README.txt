Wayne and Layne present:
Bricktronics Shield - Hardware v1.03

These are the shield design files for use with Kicad, an open source electronic design suite available for Windows, Linux, and OS X.

More details are available at http://wayneandlayne.com/bricktronics/

Design files:
-------------
bricktronics_shield.pro                 Kicad project file
bricktronics_shield.sch                 Schematic
bricktronics_shield.net                 Netlist
bricktronics_shield.brd                 PCB layout
bricktronics_shield.cmp                 Symbol to footprint mapping
wayne_and_layne_kicad_modules.mod       W&L PCB footprint library
wayne_and_layne_kicad_symbols.lib       W&L schematic symbol library

